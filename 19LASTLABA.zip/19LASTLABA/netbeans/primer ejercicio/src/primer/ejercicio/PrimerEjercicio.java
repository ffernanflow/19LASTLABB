/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primer.ejercicio;
import java.util.Scanner
/**
 *
 * @author estudiante
 */
public class PrimerEjercicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int a ;
        System.out.println("ingrese su numero");
        Scanner N1 = new Scanner(System.in);
        a = N1.nextInt();
        
        if (a%2==0){
             System.out.println("es par");
        }else {
             System.out.println("su numero es impar");
             
             
        }
        String nombre = "";
        System.out.println("ingrese su nombre");
        Scanner N2 = new Scanner(System.in);
        nombre = N2.nextLine();
        System.out.println("su nombre es: " + nombre);s
    }
    
}




    
