/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package segundo.ejercicio;
import java.util.Scanner
/**
 *
 * @author estudiante
 */
public class SEGUNDOEJERCICIO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String nombre = "";
        System.out.println("ingrese su nombre");
        Scanner N2 = new Scanner(System.in);
        nombre = N2.nextLine();
        System.out.println("su nombre es: " + nombre);
        
       
    }
    
}
